//
//  FormViewController.swift
//  madLibs
//
//  Created by Imron Hajiahmad on 9/12/17.
//  Copyright © 2017 Imron Hajiahmad. All rights reserved.
//

import UIKit

class FormViewController: UIViewController {
    @IBOutlet weak var adjectiveLabel: UITextField!
    @IBOutlet weak var verbLabel: UITextField!
    @IBOutlet weak var nounLabel: UITextField!
    @IBOutlet weak var prepositionLabel: UITextField!
    
    weak var delegate: MadLibs?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func submitButtonPressed(_ sender: UIButton) {
        delegate?.MadLibs(table: self, adj: adjectiveLabel.text!, verb: verbLabel.text!, noun: nounLabel.text!, preposition: prepositionLabel.text!)
    }

}

//
//  madLibs.swift
//  madLibs
//
//  Created by Imron Hajiahmad on 9/12/17.
//  Copyright © 2017 Imron Hajiahmad. All rights reserved.
//

import UIKit


protocol MadLibs: class {
    func MadLibs(table: UIViewController, adj: String, verb: String, noun: String, preposition: String)
}

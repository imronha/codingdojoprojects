export class Question {
    content:string = ""
    answers = [
        {response:"", support:"", likes: 0}
    ]

}

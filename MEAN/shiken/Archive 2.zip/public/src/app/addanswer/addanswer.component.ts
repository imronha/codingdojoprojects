import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addanswer',
  templateUrl: './addanswer.component.html',
  styleUrls: ['./addanswer.component.css']
})
export class AddanswerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
